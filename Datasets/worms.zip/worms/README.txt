Examples of dataset generation (MATLAB)

Create a 2D dataset with a maximum of 20 clusters. Save to file 'worms_88.txt'.
gen_2d_worms(88,20);

Create a 64D dataset with a maximum of 20 clusters. Save to file 'worms_1064.txt'.
gen_high_dim_worms(1064,20,64);


